# Optional OAW adapter

Use `AGENTS.md` for shared project guidance when it applies to the current task.
Use this host's native memory, skills, and permissions.
